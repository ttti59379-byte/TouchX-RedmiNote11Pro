package com.touchx.redmi11;
interface IInputBridge {
   boolean start(float multiplierX, float multiplierY);
   void stop();
   boolean isActive();
   String getLastError();
   String getDiagnosticLog();
}
