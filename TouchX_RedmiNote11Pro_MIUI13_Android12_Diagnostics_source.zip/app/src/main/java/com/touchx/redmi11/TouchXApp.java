package com.touchx.redmi11;

import android.app.Application;

/** Save uncaught app-side Java exceptions before Android terminates the process. */
public final class TouchXApp extends Application {
    @Override public void onCreate() {
        super.onCreate();
        DiagnosticLog.init(this);
        Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, exception) -> {
            DiagnosticLog.exception("APP_UNCAUGHT/" + thread.getName(), exception);
            if (previous != null) previous.uncaughtException(thread, exception);
        });
    }
}
