package com.touchx.redmi11;

import android.content.Context;
import android.os.Build;
import android.util.Log;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Local, bounded diagnostics. Never stores touch coordinates, key presses, or screen content. */
public final class DiagnosticLog {
    private static final Object LOCK = new Object();
    private static final String LOG_FILE = "touchx-diagnostics.txt";
    private static final int MAX_BYTES = 192 * 1024;
    private static volatile Context app;

    private DiagnosticLog() {}

    public static void init(Context context) {
        if (app == null) {
            synchronized (LOCK) {
                if (app == null) {
                    app = context.getApplicationContext();
                    appendLocked("SESSION", "TouchX diagnostic session started; "
                        + "model=" + Build.MANUFACTURER + " " + Build.MODEL
                        + "; Android=" + Build.VERSION.RELEASE
                        + "; SDK=" + Build.VERSION.SDK_INT);
                }
            }
        }
    }

    public static void event(String component, String message) {
        synchronized (LOCK) {
            appendLocked(component, message);
        }
    }

    public static void exception(String component, Throwable cause) {
        String trace = cause == null ? "(no throwable)" : Log.getStackTraceString(cause);
        event(component, "Exception / StackTrace:\n" + trace);
    }

    private static void appendLocked(String component, String message) {
        Context context = app;
        if (context == null) return;
        try {
            File f = new File(context.getFilesDir(), LOG_FILE);
            String stamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS Z", Locale.US)
                .format(new Date());
            String line = "[" + stamp + "] [" + Thread.currentThread().getName() + "] ["
                + component + "] " + String.valueOf(message) + "\n";
            byte[] bytes = line.getBytes(StandardCharsets.UTF_8);
            if (f.length() + bytes.length > MAX_BYTES) {
                // Keep a useful recent window and avoid unlimited storage growth.
                byte[] old = f.exists() ? Files.readAllBytes(f.toPath()) : new byte[0];
                int keep = Math.min(old.length, MAX_BYTES / 2);
                try (FileOutputStream out = new FileOutputStream(f, false)) {
                    out.write(("[LOG ROTATED: latest entries retained]\n").getBytes(StandardCharsets.UTF_8));
                    out.write(old, old.length - keep, keep);
                }
            }
            try (FileOutputStream out = new FileOutputStream(f, true)) { out.write(bytes); }
        } catch (Throwable ignored) {
            // Diagnostic logging must never crash the game or the application.
        }
    }

    public static String read(Context context) {
        init(context);
        synchronized (LOCK) {
            try {
                File f = new File(context.getFilesDir(), LOG_FILE);
                return f.exists() ? new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8)
                    : "(Журнал пока пуст)";
            } catch (Throwable t) {
                return "Не удалось прочитать журнал: " + Log.getStackTraceString(t);
            }
        }
    }

    public static void clear(Context context) {
        init(context);
        synchronized (LOCK) {
            try (FileOutputStream out = new FileOutputStream(new File(context.getFilesDir(), LOG_FILE), false)) {
                out.write("[Журнал очищен пользователем]\n".getBytes(StandardCharsets.UTF_8));
            } catch (Throwable ignored) { }
        }
    }
}
