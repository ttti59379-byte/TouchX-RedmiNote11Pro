package com.touchx.redmi11;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.os.Handler;
import android.os.Looper;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private final Handler h = new Handler(Looper.getMainLooper());
    private TextView status;
    private boolean waitingForShizuku = false;
    private int waitChecks = 0;
    private String lastStatus = "";

    // Shizuku delivers its Binder asynchronously after process start.
    // A single pingBinder() check can incorrectly report that the service is stopped.
    private final Shizuku.OnBinderReceivedListener onBinderReceived = () -> h.post(() -> {
        DiagnosticLog.event("SHIZUKU", "Binder received");
        if (waitingForShizuku) {
            checkShizukuConnection();
        } else {
            Bridge.connect(this);
            update();
        }
    });
    private final Shizuku.OnBinderDeadListener onBinderDead = () -> h.post(() -> {
        waitingForShizuku = false;
        DiagnosticLog.event("SHIZUKU", "Binder disconnected / dead");
        status.setText("Соединение с Shizuku потеряно. Проверь службу Shizuku.");
    });
    private final Runnable retryConnection = new Runnable() {
        @Override public void run() {
            if (!waitingForShizuku) return;
            if (Shizuku.pingBinder()) {
                checkShizukuConnection();
                return;
            }
            if (++waitChecks >= 15) {
                waitingForShizuku = false;
                DiagnosticLog.event("SHIZUKU_TIMEOUT", "Binder unavailable after 15 retries, interval=400ms");
                status.setText("TouchX не получил соединение от Shizuku. В Shizuku проверь разрешение для TouchX; затем перезапусти TouchX.");
                return;
            }
            h.postDelayed(this, 400);
        }
    };

    private void checkShizukuConnection() {
        try {
            if (!Shizuku.pingBinder()) {
                DiagnosticLog.event("SHIZUKU", "Binder not available yet");
                status.setText("Ожидание соединения Shizuku...");
                return;
            }
            waitingForShizuku = false;
            h.removeCallbacks(retryConnection);
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                DiagnosticLog.event("SHIZUKU_PERMISSION", "Permission not granted; requesting API permission");
                status.setText("Shizuku работает: требуется разрешение TouchX");
                Shizuku.requestPermission(101);
            } else {
                DiagnosticLog.event("SHIZUKU_PERMISSION", "Permission already granted");
                Bridge.connect(this);
                update();
            }
        } catch (Throwable t) {
            waitingForShizuku = false;
            DiagnosticLog.exception("SHIZUKU_CHECK", t);
            status.setText("Ошибка Shizuku: " + t.getClass().getSimpleName() + ": " + t.getMessage());
        }
    }
    private final Shizuku.OnRequestPermissionResultListener perms=(code,result)-> h.post(() -> {
        DiagnosticLog.event("SHIZUKU_PERMISSION", "Request " + code + ", result=" + result);
        if(result==PackageManager.PERMISSION_GRANTED) {Bridge.connect(this); update();}
        else if (status != null) status.setText("Shizuku: доступ TouchX не разрешён (" + result + ")");
    });
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        DiagnosticLog.init(this);
        DiagnosticLog.event("ACTIVITY", "MainActivity created");
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(32,32,32,32);
        TextView title=new TextView(this);title.setText("TouchX — Redmi Note 11 Pro 4G / MIUI 13");title.setTextSize(21);l.addView(title);
        TextView info=new TextView(this);info.setText("Экспериментальная версия для Android 12 + MIUI 13. Shizuku обязателен. Работа перехвата InputMonitor зависит от прошивки. Системные жесты защищены: верхняя и нижняя полосы, боковые края. Усиление плавное с ограниченным приростом. Три нажатия громкости вниз — аварийный СТОП.");l.addView(info);
        status=new TextView(this);status.setTextSize(16);l.addView(status);
        Button diag=new Button(this);diag.setText("Диагностика / полный StackTrace / экспорт TXT");l.addView(diag);
        diag.setOnClickListener(v->startActivity(new Intent(this, DiagnosticActivity.class)));
        Button perm=new Button(this);perm.setText("1. Подключить Shizuku");l.addView(perm);
        perm.setOnClickListener(v->{
            DiagnosticLog.event("SHIZUKU", "Manual connection requested");
            waitingForShizuku = true;
            waitChecks = 0;
            checkShizukuConnection();
            if (waitingForShizuku) {
                h.removeCallbacks(retryConnection);
                h.postDelayed(retryConnection, 400);
            }
        });
        Button access=new Button(this);access.setText("2. Включить специальные возможности");l.addView(access);
        access.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        slider(l,"Горизонталь X", "x",1.20f);
        slider(l,"Вертикаль Y", "y",1.35f);
        Button start=new Button(this);start.setText("3. Включить только для Free Fire");l.addView(start);
        start.setOnClickListener(v->{
            DiagnosticLog.event("CONTROL", "User armed capture for Free Fire");
            Bridge.prefs(this).edit().putBoolean("armed",true).apply();
            Bridge.connect(this);Bridge.refresh(this);
            Intent go = getPackageManager().getLaunchIntentForPackage("com.dts.freefireth");
            if(go==null)go=getPackageManager().getLaunchIntentForPackage("com.dts.freefiremax");
            if(go!=null)startActivity(go);
            else status.setText("Free Fire не найден. Запусти игру самостоятельно.");
        });
        Button stop=new Button(this);stop.setText("СТОП — отключить перехват");l.addView(stop);
        stop.setOnClickListener(v->{DiagnosticLog.event("CONTROL", "User pressed STOP");Bridge.stop(this);update();});
        setContentView(l);
        Shizuku.addRequestPermissionResultListener(perms);
        Shizuku.addBinderReceivedListenerSticky(onBinderReceived);
        Shizuku.addBinderDeadListener(onBinderDead);
        Bridge.connect(this);
        update();
    }
    private void slider(LinearLayout box,String label,String pref,float def){
        TextView tv=new TextView(this);box.addView(tv);
        SeekBar bar=new SeekBar(this);bar.setMax(60);
        float current=Bridge.prefs(this).getFloat(pref,def);
        bar.setProgress(Math.round((current-1f)*20f));box.addView(bar,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT));
        tv.setText(label+": "+String.format(java.util.Locale.US,"%.2f",current));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
           @Override public void onProgressChanged(SeekBar b,int n,boolean user){
               float x=1f+n/20f;tv.setText(label+": "+String.format(java.util.Locale.US,"%.2f",x));
               if(user){Bridge.prefs(MainActivity.this).edit().putFloat(pref,x).apply();Bridge.refresh(MainActivity.this);}
           }
           @Override public void onStartTrackingTouch(SeekBar s){}
           @Override public void onStopTrackingTouch(SeekBar s){}
        });
    }
    private void update(){
        try {
            String current = Bridge.status();
            if (!current.equals(lastStatus)) { DiagnosticLog.event("STATUS", current); lastStatus = current; }
            status.setText(current);
        } catch(Throwable t) { DiagnosticLog.exception("STATUS", t); status.setText(t.toString()); }
    }
    @Override protected void onResume(){
        super.onResume();
        DiagnosticLog.event("ACTIVITY", "MainActivity resumed");
        Bridge.prefs(this).edit().putBoolean("gameFocus",false).apply();
        Bridge.refresh(this);
        Bridge.connect(this);
        update();
    }
    @Override protected void onDestroy(){
        waitingForShizuku = false;
        DiagnosticLog.event("ACTIVITY", "MainActivity destroyed");
        h.removeCallbacks(retryConnection);
        Shizuku.removeBinderReceivedListener(onBinderReceived);
        Shizuku.removeBinderDeadListener(onBinderDead);
        Shizuku.removeRequestPermissionResultListener(perms);
        super.onDestroy();
    }
}
