package com.touchx.redmi11;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** In-app log viewer with one-tap copy and Android's Storage Access Framework TXT export. */
public final class DiagnosticActivity extends Activity {
    private static final int EXPORT_REQUEST = 43;
    private TextView body;
    private String cachedReport = "";

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setTitle("TouchX — диагностика");
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 24);
        TextView intro = new TextView(this);
        intro.setText("Технический журнал подключения Shizuku и InputMonitor.\n"
            + "Содержит реальные Java-исключения и StackTrace, если они произошли. "
            + "Не содержит координат пальцев и содержимого экрана.");
        root.addView(intro);

        Button reload = new Button(this);
        reload.setText("Обновить журнал");
        root.addView(reload);
        reload.setOnClickListener(v -> refresh());

        Button copy = new Button(this);
        copy.setText("Скопировать полный отчёт");
        root.addView(copy);
        copy.setOnClickListener(v -> {
            refresh();
            ClipboardManager manager = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
            if (manager != null) {
                manager.setPrimaryClip(ClipData.newPlainText("TouchX diagnostics", cachedReport));
                Toast.makeText(this, "Отчёт скопирован", Toast.LENGTH_SHORT).show();
            }
        });

        Button export = new Button(this);
        export.setText("Сохранить отчёт в TXT");
        root.addView(export);
        export.setOnClickListener(v -> {
            refresh();
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.setType("text/plain");
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.putExtra(Intent.EXTRA_TITLE, "TouchX-diagnostics.txt");
            startActivityForResult(intent, EXPORT_REQUEST);
        });

        Button clear = new Button(this);
        clear.setText("Очистить журнал");
        root.addView(clear);
        clear.setOnClickListener(v -> {
            DiagnosticLog.clear(this);
            refresh();
            Toast.makeText(this, "Журнал очищен", Toast.LENGTH_SHORT).show();
        });

        ScrollView scroll = new ScrollView(this);
        body = new TextView(this);
        body.setTextIsSelectable(true);
        body.setTextSize(12);
        body.setTypeface(Typeface.MONOSPACE);
        body.setPadding(8, 12, 8, 12);
        scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(root);
        refresh();
    }

    private void refresh() {
        String appLog = DiagnosticLog.read(this);
        String remoteLog = Bridge.remoteDiagnostics();
        String snapshot = Bridge.diagnosticSnapshot();
        cachedReport = "=== TouchX: current state ===\n" + snapshot
            + "\n\n=== App log ===\n" + appLog
            + "\n\n=== Shizuku UserService log ===\n" + remoteLog;
        body.setText(cachedReport);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != EXPORT_REQUEST || resultCode != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (uri == null) return;
        try (OutputStream stream = getContentResolver().openOutputStream(uri)) {
            if (stream == null) throw new java.io.IOException("openOutputStream returned null");
            stream.write(cachedReport.getBytes(StandardCharsets.UTF_8));
            Toast.makeText(this, "Отчёт сохранён", Toast.LENGTH_SHORT).show();
        } catch (Throwable ex) {
            DiagnosticLog.exception("EXPORT_TXT", ex);
            Toast.makeText(this, "Не удалось сохранить TXT: " + ex.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
        }
    }
}
