package com.touchx.redmi11;

import android.accessibilityservice.AccessibilityService;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;

/** Only starts on an actual Free Fire foreground window; 3×volume-down is emergency stop. */
public class GameAccessibilityService extends AccessibilityService {
    private int presses;
    private long lastPress;
    @Override protected void onServiceConnected() { DiagnosticLog.init(this); DiagnosticLog.event("ACCESSIBILITY", "AccessibilityService connected"); Bridge.connect(this); }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                && event.getEventType() != AccessibilityEvent.TYPE_WINDOWS_CHANGED) return;
        CharSequence pkg = event.getPackageName();
        if (pkg == null) return;
        String s = pkg.toString();
        boolean game = s.equals("com.dts.freefireth") || s.equals("com.dts.freefiremax");
        boolean previous = Bridge.prefs(this).getBoolean("gameFocus",false);
        if (previous != game) DiagnosticLog.event("ACCESSIBILITY", "Free Fire foreground=" + game);
        Bridge.prefs(this).edit().putBoolean("gameFocus",game).apply();
        Bridge.refresh(this);
    }
    @Override protected boolean onKeyEvent(KeyEvent event) {
        if(event.getKeyCode()==KeyEvent.KEYCODE_VOLUME_DOWN && event.getAction()==KeyEvent.ACTION_DOWN
            && event.getRepeatCount()==0) {
            long now=android.os.SystemClock.uptimeMillis();
            presses = (now-lastPress <= 1200) ? presses+1 : 1;
            lastPress=now;
            if(presses>=3) {
                // Persistently unarm capture; it must not restart on a window change.
                DiagnosticLog.event("ACCESSIBILITY", "Emergency STOP by 3x volume down");
                Bridge.stop(this);
                presses=0;
                lastPress=0;
            }
        }
        return false; // Never consume hardware volume keys
    }
    @Override public void onInterrupt() {DiagnosticLog.event("ACCESSIBILITY", "Accessibility interrupted");Bridge.stop(this);}
    @Override public void onDestroy() {DiagnosticLog.event("ACCESSIBILITY", "Accessibility destroyed");Bridge.stop(this); super.onDestroy();}
}
