package com.touchx.redmi11;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.os.RemoteException;
import rikka.shizuku.Shizuku;

/** App-side coordinator. Never activates capture when the selected game is not foreground. */
public final class Bridge {
    private static volatile IInputBridge remote;
    private static boolean binding = false;
    private static final ServiceConnection connection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder b) {
            DiagnosticLog.event("BRIDGE", "UserService binder connected: " + n.getClassName());
            remote = IInputBridge.Stub.asInterface(b);
            binding = false;
            if (appContext != null) refresh(appContext);
        }
        @Override public void onServiceDisconnected(ComponentName n) {
            DiagnosticLog.event("BRIDGE", "UserService disconnected: " + n.getClassName());
            remote = null; binding = false;
        }
    };
    private static volatile Context appContext;
    private Bridge() {}
    public static SharedPreferences prefs(Context c) {return c.getSharedPreferences("touchx11", Context.MODE_PRIVATE);}
    public static synchronized void connect(Context c) {
        appContext = c.getApplicationContext();
        DiagnosticLog.init(appContext);
        if (binding || remote != null) return;
        try {
            if (!Shizuku.pingBinder()) {
                DiagnosticLog.event("BRIDGE", "Shizuku Binder not available during connect()");
                return;
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                DiagnosticLog.event("BRIDGE", "Shizuku permission missing during connect()");
                return;
            }
            binding = true;
            DiagnosticLog.event("BRIDGE", "Binding Shizuku UserService (version 2)");
            Shizuku.UserServiceArgs args = new Shizuku.UserServiceArgs(
                new ComponentName(c.getPackageName(), InputMonitorService.class.getName()))
                .daemon(false).processNameSuffix("touch11").version(2);
            Shizuku.bindUserService(args, connection);
        } catch (Throwable e) {
            binding = false;
            DiagnosticLog.exception("BRIDGE_BIND", e);
        }
    }
    public static synchronized void refresh(Context c) {
        SharedPreferences p = prefs(c);
        boolean shouldRun = p.getBoolean("armed",false) && p.getBoolean("gameFocus",false);
        if (remote == null) {if (shouldRun) connect(c); return;}
        try {
            if (shouldRun && !remote.isActive()) {
                boolean started = remote.start(p.getFloat("x",1.20f),p.getFloat("y",1.35f));
                DiagnosticLog.event("BRIDGE_START", "Capture start returned=" + started);
                if (!started) DiagnosticLog.event("BRIDGE_START_ERROR", remote.getLastError());
            }
            if (!shouldRun && remote.isActive()) {
                remote.stop();
                DiagnosticLog.event("BRIDGE_STOP", "Capture stopped after game focus/arming changed");
            }
        } catch (Throwable e) {
            DiagnosticLog.exception("BRIDGE_REFRESH", e);
            remote = null;
            binding = false;
        }
    }
    public static synchronized void stop(Context c) {
        prefs(c).edit().putBoolean("armed",false).putBoolean("gameFocus",false).apply();
        if (remote!=null) try {remote.stop();DiagnosticLog.event("BRIDGE_STOP", "Manual stop");}
        catch(Throwable e){DiagnosticLog.exception("BRIDGE_STOP", e);}
    }
    public static String diagnosticSnapshot() {
        StringBuilder out = new StringBuilder();
        try { out.append("Shizuku binder: ").append(Shizuku.pingBinder()).append('\n'); }
        catch (Throwable e) { out.append("Shizuku binder check error: ").append(e).append('\n'); DiagnosticLog.exception("SNAPSHOT_BINDER",e); }
        try { out.append("Shizuku permission result: ").append(Shizuku.checkSelfPermission()).append('\n'); }
        catch (Throwable e) { out.append("Permission check error: ").append(e).append('\n'); DiagnosticLog.exception("SNAPSHOT_PERMISSION",e); }
        out.append("Binding in progress: ").append(binding).append('\n');
        out.append("UserService connected: ").append(remote != null).append('\n');
        Context c = appContext;
        if (c != null) {
            SharedPreferences p = prefs(c);
            out.append("Armed: ").append(p.getBoolean("armed",false)).append('\n');
            out.append("Game foreground: ").append(p.getBoolean("gameFocus",false)).append('\n');
            out.append("Multiplier X/Y: ").append(p.getFloat("x",1.20f))
                .append(" / ").append(p.getFloat("y",1.35f)).append('\n');
        }
        IInputBridge r = remote;
        if (r != null) {
            try { out.append("Capture active: ").append(r.isActive()).append('\n');
                out.append("UserService last error: ").append(r.getLastError()).append('\n'); }
            catch(Throwable e) { out.append("UserService error: ").append(e).append('\n'); DiagnosticLog.exception("SNAPSHOT_REMOTE",e); }
        }
        return out.toString();
    }
    public static String remoteDiagnostics() {
        IInputBridge r = remote;
        if (r == null) return "UserService not connected. There is no remote log yet.";
        try { return r.getDiagnosticLog(); }
        catch (Throwable e) { DiagnosticLog.exception("REMOTE_LOG", e); return "Unable to read remote log: " + e; }
    }
    public static String status() {
        if(!Shizuku.pingBinder()) return "Ожидание подключения к Shizuku (проверь разрешение приложения)";
        if(Shizuku.checkSelfPermission()!=PackageManager.PERMISSION_GRANTED) return "Shizuku: нужно разрешение";
        if(remote==null) return "Подключение к службе...";
        try {
            String error=remote.getLastError();
            if(!error.isEmpty()) return error;
            return remote.isActive()?"Активно в игре":"Готово (ожидание игры)";
        } catch(Throwable e){DiagnosticLog.exception("BRIDGE_STATUS",e);return "Ошибка подключения: "+e.getClass().getSimpleName();}
    }
}
