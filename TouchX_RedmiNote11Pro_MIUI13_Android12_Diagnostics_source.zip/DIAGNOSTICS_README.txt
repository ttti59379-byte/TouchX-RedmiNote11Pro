TouchX Redmi Note 11 Pro 4G — MIUI 13, Android 12, diagnostic build 0.5

1. Launch Shizuku and grant TouchX permission.
2. Launch TouchX and tap Connect Shizuku.
3. Open Diagnostics. Copy entire report or Save TXT via Android file picker.
4. Report includes app and UserService state, exceptions and stacktraces.
5. Motion-event coordinates and user screen contents are never logged.

GitHub: in build.yml replace the unzip archive path with:
  unzip -o TouchX_RedmiNote11Pro_MIUI13_Android12_Diagnostics_source.zip
