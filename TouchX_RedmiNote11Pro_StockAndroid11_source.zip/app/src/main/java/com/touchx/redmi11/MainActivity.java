package com.touchx.redmi11;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.os.Handler;
import android.os.Looper;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private final Handler h = new Handler(Looper.getMainLooper());
    private TextView status;
    private final Shizuku.OnRequestPermissionResultListener perms=(code,result)-> {
        if(result==PackageManager.PERMISSION_GRANTED) {Bridge.connect(this); update();}
    };
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(32,32,32,32);
        TextView title=new TextView(this);title.setText("TouchX — Redmi Note 11 Pro 4G / MIUI 13");title.setTextSize(21);l.addView(title);
        TextView info=new TextView(this);info.setText("Экспериментальная версия для Android 11 + MIUI 13. Shizuku обязателен. Работа перехвата InputMonitor зависит от прошивки. Системные жесты защищены: верхняя и нижняя полосы, боковые края. Усиление плавное с ограниченным приростом. Три нажатия громкости вниз — аварийный СТОП.");l.addView(info);
        status=new TextView(this);status.setTextSize(16);l.addView(status);
        Button perm=new Button(this);perm.setText("1. Подключить Shizuku");l.addView(perm);
        perm.setOnClickListener(v->{
            try {if(!Shizuku.pingBinder()){status.setText("Сначала запусти Shizuku");return;}
                if(Shizuku.checkSelfPermission()!=PackageManager.PERMISSION_GRANTED)
                    Shizuku.requestPermission(101);
                else Bridge.connect(this);
                update();
            } catch(Exception e){status.setText(e.toString());}
        });
        Button access=new Button(this);access.setText("2. Включить специальные возможности");l.addView(access);
        access.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        slider(l,"Горизонталь X", "x",1.20f);
        slider(l,"Вертикаль Y", "y",1.35f);
        Button start=new Button(this);start.setText("3. Включить только для Free Fire");l.addView(start);
        start.setOnClickListener(v->{
            Bridge.prefs(this).edit().putBoolean("armed",true).apply();
            Bridge.connect(this);Bridge.refresh(this);
            Intent go = getPackageManager().getLaunchIntentForPackage("com.dts.freefireth");
            if(go==null)go=getPackageManager().getLaunchIntentForPackage("com.dts.freefiremax");
            if(go!=null)startActivity(go);
            else status.setText("Free Fire не найден. Запусти игру самостоятельно.");
        });
        Button stop=new Button(this);stop.setText("СТОП — отключить перехват");l.addView(stop);
        stop.setOnClickListener(v->{Bridge.stop(this);update();});
        setContentView(l);
        Shizuku.addRequestPermissionResultListener(perms);
        Bridge.connect(this);
        update();
    }
    private void slider(LinearLayout box,String label,String pref,float def){
        TextView tv=new TextView(this);box.addView(tv);
        SeekBar bar=new SeekBar(this);bar.setMax(60);
        float current=Bridge.prefs(this).getFloat(pref,def);
        bar.setProgress(Math.round((current-1f)*20f));box.addView(bar,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT));
        tv.setText(label+": "+String.format(java.util.Locale.US,"%.2f",current));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
           @Override public void onProgressChanged(SeekBar b,int n,boolean user){
               float x=1f+n/20f;tv.setText(label+": "+String.format(java.util.Locale.US,"%.2f",x));
               if(user){Bridge.prefs(MainActivity.this).edit().putFloat(pref,x).apply();Bridge.refresh(MainActivity.this);}
           }
           @Override public void onStartTrackingTouch(SeekBar s){}
           @Override public void onStopTrackingTouch(SeekBar s){}
        });
    }
    private void update(){try{status.setText(Bridge.status());}catch(Throwable t){status.setText(t.toString());}}
    @Override protected void onResume(){super.onResume();Bridge.prefs(this).edit().putBoolean("gameFocus",false).apply();Bridge.refresh(this);update();}
    @Override protected void onDestroy(){Shizuku.removeRequestPermissionResultListener(perms);super.onDestroy();}
}
