package com.touchx.redmi11;

import android.content.Context;
import android.hardware.input.InputManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Process;
import android.os.SystemClock;
import android.view.InputChannel;
import android.view.InputEvent;
import android.view.InputEventReceiver;
import android.view.InputMonitor;
import android.view.MotionEvent;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/** Shizuku shell UserService. Android 11-specific InputMonitor prototype (experimental). */
public final class InputMonitorService extends IInputBridge.Stub {
    private static final int SYNTHETIC_EDGE_TAG = 0x40000000;
    private final HandlerThread thread = new HandlerThread("TouchX11-capture",Process.THREAD_PRIORITY_DISPLAY);
    private Handler handler;
    private InputMonitor monitor;
    private InputEventReceiver receiver;
    private Object inputManager;
    private Method injectMethod;
    private volatile boolean active;
    private volatile String error = "";
    private float scaleX=1.20f,scaleY=1.35f;
    private boolean pilfered=false;
    // Exclude Android 11 status bar, navigation bar and edge gestures.
    private int heightPx=2400, widthPx=1080;
    // The extra distance is bounded: this is NOT automatic head targeting.
    private float softExtra(float movement, float gain, float distance){
        float delta = (float)(Math.tanh(movement/distance)*(gain-1f)*distance);
        return movement + delta;
    }
    private void readScreenSize(){
        try {
            // A Shizuku UserService may not have an Application context;
            // obtain display metrics through the display service when possible.
            Class<?> c=Class.forName("android.hardware.display.DisplayManagerGlobal");
            Object g=c.getDeclaredMethod("getInstance").invoke(null);
            android.view.DisplayInfo info=(android.view.DisplayInfo)c.getDeclaredMethod("getDisplayInfo",int.class).invoke(g,0);
            widthPx=info.logicalWidth; heightPx=info.logicalHeight;
        }catch(Throwable ignored){}
    }
    private final Map<Integer,float[]> starts=new HashMap<>();
    private final Map<Integer,float[]> endpoints=new HashMap<>();

    public InputMonitorService(){ thread.start(); handler=new Handler(thread.getLooper()); }
    public InputMonitorService(Context ignored){this();}

    @Override public boolean start(float sx,float sy) {
        if(sx<1f||sy<1f||sx>4f||sy>4f) { error="Некорректные множители";return false; }
        scaleX=sx;scaleY=sy;
        final Object lock=new Object();final boolean[] result={false};final boolean[] done={false};
        handler.post(()->{
            result[0]=startInternal();done[0]=true;
            synchronized(lock){lock.notifyAll();}
        });
        synchronized(lock){if(!done[0])try{lock.wait(3000L);}catch(InterruptedException e){Thread.currentThread().interrupt();}}
        return result[0];
    }
    private boolean startInternal() {
        if(active) return true;
        error="";
        try {
            if(Process.myUid()!=2000 && Process.myUid()!=0) throw new SecurityException("Нужен shell UID 2000 через Shizuku");
            Class<?> imClass=Class.forName("android.hardware.input.InputManager");
            inputManager=imClass.getDeclaredMethod("getInstance").invoke(null);
            Method make=imClass.getDeclaredMethod("monitorGestureInput",String.class,int.class);
            make.setAccessible(true);
            monitor=(InputMonitor)make.invoke(inputManager,"TouchX11",0);
            injectMethod=imClass.getDeclaredMethod("injectInputEvent", InputEvent.class,int.class);
            injectMethod.setAccessible(true);
            InputChannel channel=monitor.getInputChannel();
            receiver=new InputEventReceiver(channel,Looper.myLooper()) {
                @Override public void onInputEvent(InputEvent event) {
                    try{ if(event instanceof MotionEvent) handle((MotionEvent)event); }
                    catch(Throwable t) {error="Ошибка ввода: "+ t.getClass().getSimpleName(); handler.post(InputMonitorService.this::stopInternal);}
                    finally{finishInputEvent(event,true);}
                }
            };
            // No timer: capture remains active while the selected game is foreground
            // and the user keeps TouchX armed. Triple volume-down disables it.
            readScreenSize();
            active=true;
            return true;
        }catch(Throwable e){error="InputMonitor недоступен в MIUI 13: "+e.getClass().getSimpleName()+" — "+e.getMessage();stopInternal();return false;}
    }
    private void handle(MotionEvent e) throws Exception {
        if(!active) return;
        if((e.getEdgeFlags() & SYNTHETIC_EDGE_TAG)!=0) return;
        if((e.getSource() & android.view.InputDevice.SOURCE_TOUCHSCREEN)!=android.view.InputDevice.SOURCE_TOUCHSCREEN)return;
        int action=e.getActionMasked();
        if(action==MotionEvent.ACTION_DOWN){
            starts.clear();endpoints.clear();pilfered=false;
            // Never grab top notifications, bottom navigation or side-back gestures.
            float px=e.getX(0),py=e.getY(0);
            if(py<heightPx*0.10f || py>heightPx*0.94f || px<widthPx*0.015f || px>widthPx*0.985f)
                return;
            // Explicitly grab only a gesture started in the game area.
            monitor.pilferPointers(); pilfered=true;
        }
        if(!pilfered) return;
        int cnt=e.getPointerCount();
        MotionEvent.PointerProperties[] p=new MotionEvent.PointerProperties[cnt];
        MotionEvent.PointerCoords[] c=new MotionEvent.PointerCoords[cnt];
        for(int i=0;i<cnt;i++) {
            int id=e.getPointerId(i);
            float x=e.getX(i),y=e.getY(i);
            if(!starts.containsKey(id)) {starts.put(id,new float[]{x,y});endpoints.put(id,new float[]{x,y});}
            float[] origin=starts.get(id);
            float tx=origin[0]+softExtra(x-origin[0],scaleX,widthPx*0.11f);
            float ty=origin[1]+softExtra(y-origin[1],scaleY,heightPx*0.045f);
            p[i]=new MotionEvent.PointerProperties();e.getPointerProperties(i,p[i]);
            c[i]=new MotionEvent.PointerCoords();e.getPointerCoords(i,c[i]);
            c[i].x=Math.max(0f,Math.min(widthPx-1f,tx));
            c[i].y=Math.max(0f,Math.min(heightPx-1f,ty));
            endpoints.put(id,new float[]{tx,ty});
        }
        MotionEvent copy=MotionEvent.obtain(e.getDownTime(),SystemClock.uptimeMillis(),e.getAction(),cnt,p,c,
            e.getMetaState(),e.getButtonState(),e.getXPrecision(),e.getYPrecision(),e.getDeviceId(),
            e.getEdgeFlags()|SYNTHETIC_EDGE_TAG,e.getSource(),e.getFlags());
        try {
            Object ok=injectMethod.invoke(inputManager,copy,0); // 0 = ASYNC; avoid blocking raw input receiver.
            if(ok instanceof Boolean && !((Boolean)ok)) throw new IllegalStateException("injectInputEvent = false");
        } finally {copy.recycle();}
        if(action==MotionEvent.ACTION_UP || action==MotionEvent.ACTION_CANCEL) {starts.clear();endpoints.clear();pilfered=false;}
        if(action==MotionEvent.ACTION_POINTER_UP){ int id=e.getPointerId(e.getActionIndex());starts.remove(id);endpoints.remove(id); }
    }
    @Override public void stop(){
        // Disarm immediately: do not let further touch events get modified while
        // the capture thread drains already queued events.
        active=false;
        if(handler!=null)handler.post(this::stopInternal);
    }
    private void stopInternal(){active=false;pilfered=false;starts.clear();endpoints.clear();
        if(receiver!=null){try{receiver.dispose();}catch(Throwable ignored){}receiver=null;}
        if(monitor!=null){try{monitor.dispose();}catch(Throwable ignored){}monitor=null;}
    }
    @Override public boolean isActive(){return active;}
    @Override public String getLastError(){return error;}
}
